package game;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Placeholder to create the Suite of testing class related to the CardDeck class
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({CardDeckManipulationTest.class, CardDeckUtilityMethodsTest.class})
public class CardDeckTestSuite {

}
