package game;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Placeholder to create the Suite of all the test classes in the project
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({CardDeckTestSuite.class, GameTestSuite.class, PlayerTestSuite.class})
public class CompleteTestSuite {
}
