package game;

/**
 * Executable game the runs the game
 *
 */
public class CardGame {

    /**
     * Creates a game object and runs it
     * 
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.run();
    }
}
